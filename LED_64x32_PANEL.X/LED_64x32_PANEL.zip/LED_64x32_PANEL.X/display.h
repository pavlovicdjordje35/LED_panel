#ifndef DISPLAY_H
#define	DISPLAY_H


void setup(void);
void loop(void);







#endif	/* DISPLAY_H */

