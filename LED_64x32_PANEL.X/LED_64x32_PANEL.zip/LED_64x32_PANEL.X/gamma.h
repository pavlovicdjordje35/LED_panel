/* 
 * File:   gamma.h
 * Author: Jovan
 *
 * Created on April 26, 2018, 6:56 PM
 */

#ifndef GAMMA_H
#define	GAMMA_H

//#define gamma1(x) gamma[x]

const unsigned char gamma_curve[256]=// gamma=2.2
{        
};


#endif	/* GAMMA_H */

